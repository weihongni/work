#include<stdio.h>

int main(void)
{
    int i,j;
    j = 0;
    i = j + 1;
    printf("hello world\n");
    printf("the result is %d\n",i);

    return 0;
}
